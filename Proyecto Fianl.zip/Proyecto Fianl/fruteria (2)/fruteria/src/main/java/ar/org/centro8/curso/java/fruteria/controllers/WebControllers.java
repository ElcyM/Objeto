package ar.org.centro8.curso.java.fruteria.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.java.fruteria.entities.Cliente;
import ar.org.centro8.curso.java.fruteria.entities.Factura;
import ar.org.centro8.curso.java.fruteria.entities.itemFactura;
import ar.org.centro8.curso.java.fruteria.repositories.ClienteRepositoryRepository;
import ar.org.centro8.curso.java.fruteria.repositories.FacturaRepository;
import ar.org.centro8.curso.java.fruteria.repositories.itemFacturaRepository;


@Controller
public class WebController {
    
    private ClienteRepository ClienteRepository=new ClienteRepository();
    private FacturaRepository facturaRepository=new FacturaRepository();
    private ItemFacturaRepository itemFacturaRepository=new itemFacturaRepository();
    private String mensajeCliente="Ingrese un nuevo Cliente!";
    private String mensajeFactura="Ingrese un nuevo Factura!";
    private String mensajeitemFactura="Ingrese un nuevo itemFactura!";

    @GetMapping("/")
    public String getIndex(){
        return "index";
    }

    @GetMapping("/cliente")
    public String getCliente(@RequestParam(name="buscarNombre", required = false, defaultValue="") String buscarNombre,
                                 Model model){
        model.addAttribute("mensajeCliente", mensajeCliente);
        model.addAttribute("cliente", new Cliente());

        //model.addAttribute("clientes", clientesRepository.getAll());
        model.addAttribute("likeDireccion", clienteRepository.getLikeDireccion(buscarDireccion));
        return "cliente";
    }

    @GetMapping("/factura")
    public String getFactura(@RequestParam(name="buscarFechaFactura", required = false, defaultValue="") String buscarFechaFactura,
                    Model model){
        model.addAttribute("mensajeFactura", mensajeFactura);
        model.addAttribute("factura", new Factura());
        model.addAttribute("likeFechaFactura", facturaRepository.getLikeFechaFactura(buscarFechaFactura));
        model.addAttribute("factura", clienteRepository.getAll());
        return "factura";
    }

    @PostMapping("/saveCliente")
    public String save(@ModelAttribute Cliente cliente){
        try {
            clienteRepository.save(cliente);
            mensajeCliente="Se guardo el cliente id: "+cliente.getId();
        } catch (Exception e) {
            mensajeCliente="Ocurrio un error";
        }
        return "redirect:factura";
    }

    @PostMapping("/saveFactura")
    public String save(@ModelAttribute Factura factura){
        try {
            facturaRepository.save(factura);
            mensajeFactura="Se guardo el factura id: "+factura.getId();
        } catch (Exception e) {
            mensajeFactura="Ocurrio un error";
        }
        return "redirect:factura";
    }
    @GetMapping("/itemFactura")
    public String getitemFactura(@RequestParam(name="buscarFechaFactura", required = false, defaultValue="") String buscarFechaFactura,
                    Model model){
        model.addAttribute("mensajeFacturas", mensajeitemFactura);
        model.addAttribute("facturas", new Facturas());
        model.addAttribute("likeFechaFactura", itemFacturaRepository.getLikeFechaFactura(buscarFechaFactura));
        model.addAttribute("itrmFactura", clienteRepository.getAll());
        return "factura";
    }

    @PostMapping("/saveCliente")
    public String save(@ModelAttribute Cliente cliente){
        try {
            clienteRepository.save(cliente);
            mensajeCliente="Se guardo el cliente id: "+cliente.getId();
        } catch (Exception e) {
            mensajeCliente="Ocurrio un error";
        }
        return "redirect:factura";
    }

    @PostMapping("/saveFactura")
    public String save(@ModelAttribute Factura factura){
        try {
            facturaRepository.save(factura);
            mensajeFactura="Se guardo el factura id: "+factura.getId();
        } catch (Exception e) {
            mensajeitemFactura="Ocurrio un error";
        }
        return "redirect:factura";
    }











}

