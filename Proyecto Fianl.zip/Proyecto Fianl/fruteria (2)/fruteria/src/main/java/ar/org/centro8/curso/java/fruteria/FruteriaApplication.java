package ar.org.centro8.curso.java.fruteria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FruteriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FruteriaApplication.class, args);
	}

}
