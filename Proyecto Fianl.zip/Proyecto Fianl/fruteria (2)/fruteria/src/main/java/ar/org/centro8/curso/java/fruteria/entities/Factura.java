package ar.org.centro8.curso.java.fruteria.entities;
public class Factura {
    private int id;
    private String nombre;
    private String direccion;

    public Factura() {
    }
    public Factura(String , String direccion, idFacturas) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.idFacturas = idFacturas;
    }


}
    