package ar.org.centro8.curso.java.fruteria.repositories;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.fruteria.connectors.Connector;
import ar.org.centro8.curso.java.fruteria.entities.Clientes;

public class ClientesRepository {
    private Connection conn = Connector.getConnection();

}
public void save (Clientes clientes) {
       if (Clientes == null) return;
       try (PreparedStatement ps = conn PreparedStatement(
        "insert into clientes (nombre, direccion,)values (?,?)"
        PreparedStatement.RETURN_GENERATED_KEYS)) {
        ps.setString(1, cliente.getNombre());    
        ps.setString(2, clientes.getDireccion());
        ps.execute();
        ResultSet rs = ps.getGeneratedKeys();
        if (rs.next())
            cliente.setCodigo(rs.getInt(1));
    } catch (Exception e) {
        System.out.println(e);
    }
}
}public List<CLiente> getAll(){
    try ResultSet rs = conn.createStatement().executeQuery("select * from clientes")) {
while (rs.next()){
    List.add(new Clientes(
        
    ))
}

    }
}
