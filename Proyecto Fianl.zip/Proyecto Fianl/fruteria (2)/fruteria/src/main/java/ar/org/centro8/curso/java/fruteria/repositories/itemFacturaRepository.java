package ar.org.centro8.curso.java.fruteria.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.fruteria.connectors.Connector;
import ar.org.centro8.curso.java.fruteria.entities.itemFacturas;

public class itemFacturasRepository {
    private Connection conn = Connector.getConnection();
    

    
}