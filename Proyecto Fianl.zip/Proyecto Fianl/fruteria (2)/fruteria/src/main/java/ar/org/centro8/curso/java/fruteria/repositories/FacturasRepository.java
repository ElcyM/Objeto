package ar.org.centro8.curso.java.fruteria.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.fruteria.connectors.Connector;
import ar.org.centro8.curso.java.fruteria.entities.Facturas;

public class FacturasRepository {
    private Connection conn = Connector.getConnection();
    

    
}