-- A Informar la lista de productos vendidos el día de hoy.
SELECT c.nombre, f.fechaFactura, i.nombre AS nombreProducto, i.producto, i.precio, i.cantidad, f.totalFacturado 
	FROM clientes c
	JOIN facturas f ON c.id = f.idCliente
	JOIN itemFacturas i ON f.idFactura = i.idFactura; 
   
-- Consulta para obtener la información de los clientes y sus facturas:
SELECT c.id, c.nombre, c.direccion, f.numero, f.fechaFactura, f.totalFacturado
FROM clientes c
JOIN facturas f ON c.id = f.idCliente;

-- Consulta para obtener la información detallada de los artículos comprados en cada factura:
SELECT f.numero, i.nombre, i.producto, i.precio, i.cantidad
FROM facturas f
JOIN itemFacturas i ON f.numero = i.idFactura;

-- Consulta para obtener el total facturado por cada cliente:
SELECT c.id, c.nombre, SUM(f.totalFacturado) AS total_facturado
FROM clientes c
JOIN facturas f ON c.id = f.idCliente
GROUP BY c.id, c.nombre;

-- Consulta para obtener los clientes que han comprado un producto específico:
SELECT c.id, c.nombre
FROM clientes c
JOIN itemFacturas i ON c.id = i.idCliente
WHERE i.producto = 'nombre_del_producto'; 

-- Consulta para obtener los clientes que no han realizado ninguna compra:
SELECT c.id, c.nombre
FROM clientes c
LEFT JOIN facturas f ON c.id = f.idCliente
WHERE f.idCliente IS NULL;
    
select * from fruteria;
    
    
    
    
    
    
    