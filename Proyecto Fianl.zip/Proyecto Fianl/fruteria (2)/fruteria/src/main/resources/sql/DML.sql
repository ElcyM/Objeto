insert into clientes(id,nombre, direccion) 
							values (1,'Susana Geonzalez', 'San Martin 1423, San Martin, Provincia Bs.As.');
insert into clientes(id,nombre, direccion) 
							values (2,'Luis Martinez', 'Lavalle 5895, Flores, CABA.');
insert into clientes(id,nombre, direccion)
							values (3,'Martin
                            Ramirez', 'Roldan 4125, Villa Ballester, Provincia Bs.As.');
insert into clientes(id,nombre, direccion)
							values (4,'Eugenia Lujan', 'G Marconi 1468, Olivos, Provincia Bs.As.');
insert into clientes(id,nombre, direccion) 
							values (5,'Sergio Rodriguez', 'Mercedez 1605, Olivos, Provincia Bs.As.');
insert into clientes(id,nombre, direccion)
							values (6,'Norma Forni', 'Medrano 120, Martinez, Provincia Bs.As');
                
insert into facturas (numero,fechaFactura,totalFacturado,idCliente,idFactura)
							values(1,curdate(),25,1,1);
insert into facturas(numero, fechaFactura, totalFacturado, idCliente, idFactura)
							values(2,curdate(), 30, 2,2 );
insert into facturas(numero, fechaFactura, totalFacturado, idCliente, idFactura) 
							values(3,curdate(), 12, 3, 3);
insert into facturas(numero, fechaFactura, totalFacturado, idCliente, idFactura) 
							values(4,curdate(), 35, 4, 4);
insert into facturas(numero, fechaFactura, totalFacturado, idCliente, idFactura) 
							values(5, curdate(), 9, 5, 5);  
insert into facturas(numero,fechaFactura, totalFacturado, idCliente, idFactura)  
							values(6,curdate(), 7, 6, 6);
                            
insert into itemFacturas(id,idFactura, nombre, producto, precio, cantidad, idCliente)
						values (1,1, 'Fruta', 'Manzana', 250, 10,1);
insert into itemFacturas(id,idFactura, nombre, producto, precio, cantidad, idCliente) 
						values (2,2, 'Fruta', 'Durazno', 500, 5,2); 
insert into itemFacturas(id,idFactura, nombre, producto, precio, cantidad, idCliente) 
						values (3,3, 'Fruta', 'Banana', 300, 12,3);
insert into itemFacturas(id,idFactura, nombre, producto, precio, cantidad, idCliente) 
						values (4,4, 'Fruta', 'Pera', 250, 3,4);
insert into itemFacturas(id,idFactura, nombre, producto, precio, cantidad, idCliente) 
						values (5,5, 'Fruta', 'Frutilla', 800, 15,5);
insert into itemFacturas(id,idFactura, nombre, producto, precio, cantidad, idCliente) 
						values (6,6, 'Fruta', 'Naranja', 400, 5,6);
        
