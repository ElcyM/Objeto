DROP DATABASE if EXISTS fruteria;
create database fruteria;
use fruteria;
DROP TABLE FACTURAS;
DROP TABLE CLIENTES;
DROP TABLE itemFACTURA;
      
create table clientes(
   id int auto_increment primary key,
   nombre  varchar(100) not null,
   direccion varchar(100) not null
);


 create table facturas(
   numero int auto_increment primary key,
   fechaFactura datetime,
   totalFacturado int,
   idCliente int not null,
   idFactura int not null,
    constraint Fk_facturas_idCli
	foreign key (idCliente)
	references clientes(id)
    on delete cascade
);


create table itemFacturas(
	id int auto_increment primary key,
    idFactura int,
	nombre varchar(100) not null,
    producto varchar(100),
    precio int,
    cantidad int,
    idCliente int not null,
    constraint Fk_itemFacturas_idCli
	foreign key (idCliente)
	references clientes(id)
    on delete cascade 
);

    	

